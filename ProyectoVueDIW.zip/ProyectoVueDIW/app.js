new Vue({ //Obtener todos los equipos
    el: '#teams',
    data() {
        return {
            textSearch: "",
            teams: []
        }
    },
    created() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/teams",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0"
            }
        })
            .then(response => {
                this.teams = response.data.data
            }).catch(e => {
                console.log(e)
            })
    },
    computed: { //Filtro de equipos por division
        teamsFilter: function() {
          var textSearch = this.textSearch;
          return this.teams.filter(function(el) {
            return el.division.toLowerCase().indexOf(textSearch.toLowerCase()) !== -1;
          });
        }
    }
});

new Vue({ //Obtener todos los jugadores (en este caso mostramos una lista de 25)
    el: '#players',
    data() {
        return {
            playerSearch: "",
            players: []
        }
    },
    created() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/players",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0",
                "per_page": "25"
            }
        })

            .then(response => {
                this.players = response.data.data
                console.log(this.players)
            }).catch(e => {
                console.log(e)
            })
    },
    computed: { //Filtro de jugadores por apellido
        playersFilter: function() {
          var playerSearch = this.playerSearch;
          return this.players.filter(function(el) {
            return el.last_name.toLowerCase().indexOf(playerSearch.toLowerCase()) !== -1;
          });
        }
    }
});

new Vue({ //Obtener todos los partidos (en este caso mostramos una lista de 25)
    el: '#games',
    data() {
        return {
            games: []
        }
    },
    created() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/games",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0",
                "per_page": "25"
            }
        })

            .then(response => {
                this.games = response.data.data
            }).catch(e => {
                console.log(e)
            })
    }

});




