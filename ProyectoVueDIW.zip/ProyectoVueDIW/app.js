new Vue({
    el: '#app',
    data() {
        return {
            teams: [] 
        }
    },
    mounted() {
        axios({
            "method":"GET",
            "url":"https://free-nba.p.rapidapi.com/teams",
            "headers":{
            "content-type":"application/octet-stream",
            "x-rapidapi-host":"free-nba.p.rapidapi.com",
            "x-rapidapi-key":"150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            },"params":{
            "page":"0"
            }
            })
            .then(response => {
                this.teams = response.data.data
            }).catch(e => {
                console.log(e)
            })
    }
})