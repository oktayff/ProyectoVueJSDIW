new Vue({ //Obtener todos los equipos
    el: '#app',
    data() {
        return {
            teams: []
        }
    },
    mounted() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/teams",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0"
            }
        })
            .then(response => {
                this.teams = response.data.data
            }).catch(e => {
                console.log(e)
            })
    },
});

new Vue({ //Obtener todos los partidos (en este caso mostramos una lista de 25)
    el: '#games',
    data() {
        return {
            games: []
        }
    },
    mounted() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/games",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0",
                "per_page": "25"
            }
        })

            .then(response => {
                this.games = response.data.data
            }).catch(e => {
                console.log(e)
            })
    }

})

new Vue({ //Obtener todos los jugadores (en este caso mostramos una lista de 15)
    el: '#players',
    data() {
        return {
            players: []
        }
    },
    mounted() {
        axios({
            "method": "GET",
            "url": "https://free-nba.p.rapidapi.com/players",
            "headers": {
                "content-type": "application/octet-stream",
                "x-rapidapi-host": "free-nba.p.rapidapi.com",
                "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
            }, "params": {
                "page": "0",
                "per_page": "15"
            }
        })

            .then(response => {
                this.players = response.data.data
                console.log(this.players)
            }).catch(e => {
                console.log(e)
            })
    }
})

new Vue({ //Obtener todos los jugadores (en este caso mostramos una lista de 15)
    el: '#playersEs',
    data() {
        return {
            playerEs: []
        }
    },
    mounted() {
    }, methods: {
        buscarJug() {

            axios({
                "method": "GET",
                "url": "https://free-nba.p.rapidapi.com/players/" + this.$refs.pid.value,
                "headers": {
                    "content-type": "application/octet-stream",
                    "x-rapidapi-host": "free-nba.p.rapidapi.com",
                    "x-rapidapi-key": "150c21a252msh32d2b3ca53cf3f1p13878ajsn24817a2fe099"
                }
            })
                .then(response => {
                    this.playerEs = response.data.data
                    console.log(playersEs)
                }).catch(e => {
                    console.log(e)
                })

        }

    }
})