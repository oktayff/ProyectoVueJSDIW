package com.boot.empresaSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
