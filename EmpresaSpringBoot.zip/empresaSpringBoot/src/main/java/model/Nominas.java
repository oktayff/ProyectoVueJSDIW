package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Nominas")
public class Nominas {
	
	@Id
	private String dni;
	
	@Column(name="Sueldo")
	private int sueldo;
	
	public Nominas (String dni, int sueldo) {
		
		this.dni = dni;
		this.sueldo = sueldo;
	}
	
	public Nominas () {
		super();
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getSueldo() {
		return sueldo;
	}

	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Nominas [dni=" + dni + ", sueldo=" + sueldo + "]";
	}
	
}
