package repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Nominas;

public interface NominasRepository extends JpaRepository<Nominas, String> {

}
