package service;

public class EmpleadosService {

}
