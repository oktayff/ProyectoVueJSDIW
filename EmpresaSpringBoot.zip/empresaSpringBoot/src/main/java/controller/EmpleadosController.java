package controller;

public class EmpleadosController {

}
